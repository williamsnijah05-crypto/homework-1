MIS 7375 Homework 1 — Upload Guide

W3Spaces folder structure:
YOUR-SPACE-NAME/
└── mis7375/
    └── homework1/
        ├── patient-form.html
        ├── style.css
        ├── thankyou.html
        └── carebridge-logo.png

Replace:
1. YOUR NAME AS IT APPEARS IN THE UH ROSTER in the HTML/CSS comments.
2. YOUR-SPACE-NAME with your actual W3Spaces username/space name.

Expected main URL:
https://YOUR-SPACE-NAME.w3spaces.com/mis7375/homework1/patient-form.html

Other required deliverables:
- mis7375-homework1.xlsx = data dictionary
- mis7375-homework1.png = diagram

The HTML uses only local references for the logo and stylesheet. The date is generated dynamically with inline JavaScript.
